#!/usr/bin/env bash
set -euo pipefail

APP_DIR="pizza-tagil-app"

echo "==> Создаю проект: $APP_DIR"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"
cd "$APP_DIR"

echo "==> Vite React+TS"
npm create vite@latest . -- --template react-ts >/dev/null

echo "==> Устанавливаю зависимости"
npm i >/dev/null
npm i react-router-dom >/dev/null

echo "==> Создаю структуру папок"
mkdir -p src/state src/data src/screens src/ui

echo "==> Пишу файлы"

cat > src/main.tsx <<'EOF'
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import "./styles.css";
import { AppProvider } from "./state/AppState";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AppProvider>
        <App />
      </AppProvider>
    </BrowserRouter>
  </React.StrictMode>
);
EOF

cat > src/App.tsx <<'EOF'
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Home from "./screens/Home";
import Cart from "./screens/Cart";
import Builder from "./screens/Builder";
import Profile from "./screens/Profile";
import Track from "./screens/Track";
import BottomNav from "./ui/BottomNav";
import TopBar from "./ui/TopBar";

export default function App() {
  const loc = useLocation();
  const showNav = !loc.pathname.startsWith("/builder");

  return (
    <div className="app">
      <TopBar />
      <main className="page">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/track" element={<Track />} />
          <Route path="/builder/:pizzaId" element={<Builder />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      {showNav && <BottomNav />}
    </div>
  );
}
EOF

cat > src/data/catalog.ts <<'EOF'
export const PIZZAS = [
  { id: "margarita", title: "Маргарита", basePrice: 450, category: "Классика", image: "https://images.unsplash.com/photo-1601924582971-c8f2f25a6b0a?w=1200&auto=format&fit=crop&q=60" },
  { id: "pepperoni", title: "Пепперони", basePrice: 520, category: "Классика", image: "https://images.unsplash.com/photo-1548365328-8b849e6f3d2b?w=1200&auto=format&fit=crop&q=60" },
  { id: "fourcheese", title: "4 Сыра", basePrice: 620, category: "Премиум", image: "https://images.unsplash.com/photo-1541745537411-b8046dc6d66c?w=1200&auto=format&fit=crop&q=60" },
  { id: "mushroom", title: "Грибная", basePrice: 540, category: "Классика", image: "https://images.unsplash.com/photo-1600628422019-1d5e64e9c1d2?w=1200&auto=format&fit=crop&q=60" },
  { id: "bbq", title: "Барбекю", basePrice: 590, category: "Острые", image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=1200&auto=format&fit=crop&q=60" },
  { id: "vegan", title: "Веган", basePrice: 560, category: "Веган", image: "https://images.unsplash.com/photo-1604917877934-07d8d248d396?w=1200&auto=format&fit=crop&q=60" },
] as const;

export const ADDONS = [
  { id: "cola", title: "Кола 0.5", price: 119, kind: "Напитки", image: "https://images.unsplash.com/photo-1527960471264-932f39eb5846?w=1200&auto=format&fit=crop&q=60" },
  { id: "mors", title: "Морс", price: 99, kind: "Напитки", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=1200&auto=format&fit=crop&q=60" },
  { id: "garlic", title: "Соус чесночный", price: 49, kind: "Соусы", image: "https://images.unsplash.com/photo-1604909052743-94e0ed2f3b8b?w=1200&auto=format&fit=crop&q=60" },
  { id: "bbqsauce", title: "Соус BBQ", price: 59, kind: "Соусы", image: "https://images.unsplash.com/photo-1606857521015-7f9fcf3f3d7f?w=1200&auto=format&fit=crop&q=60" },
  { id: "cheesecake", title: "Чизкейк", price: 149, kind: "Десерты", image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=1200&auto=format&fit=crop&q=60" },
] as const;

export const CATEGORIES = ["Все", "Классика", "Премиум", "Веган", "Острые", "Напитки", "Закуски", "Десерты"] as const;
EOF

cat > src/state/AppState.tsx <<'EOF'
import React, { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import { PIZZAS, ADDONS } from "../data/catalog";

export type Category = "Все" | "Классика" | "Премиум" | "Веган" | "Острые" | "Напитки" | "Закуски" | "Десерты";
export type Dough = "Тонкое" | "Традиционное";
export type Size = 25 | 30 | 35;
export type AddonId = string;

export type CartItem = {
  id: string;
  type: "pizza" | "addon";
  title: string;
  image: string;
  price: number; // цена за 1 шт
  qty: number;
  meta?: {
    size?: Size;
    dough?: Dough;
    addons?: { id: AddonId; title: string; price: number }[];
  };
};

export type OrderStatus = "Принят" | "Готовится" | "В пути" | "Доставлен";

export type Order = {
  id: string;
  createdAt: number;
  items: CartItem[];
  subtotal: number;
  delivery: number;
  discount: number;
  total: number;
  address?: {
    phone: string;
    street: string;
    intercom?: string;
    comment?: string;
  };
  payMethod?: "СБП" | "Наличными";
  status: OrderStatus;
  etaMin: number;
};

type State = {
  category: Category;
  cart: CartItem[];
  promoCode: string;
  promoApplied: { code: string; discountRub: number } | null;
  profile: { name: string; phone: string };
  savedAddresses: { label: string; phone: string; street: string; intercom?: string }[];
  currentOrder: Order | null;
  orderHistory: Order[];
};

type Action =
  | { type: "setCategory"; category: Category }
  | { type: "addPizza"; payload: { pizzaId: string; size: Size; dough: Dough; addonIds: AddonId[] } }
  | { type: "addAddon"; addonId: string }
  | { type: "inc"; id: string }
  | { type: "dec"; id: string }
  | { type: "remove"; id: string }
  | { type: "clearCart" }
  | { type: "setPromo"; code: string }
  | { type: "applyPromo"; code: string }
  | { type: "clearPromo" }
  | { type: "checkout"; payload: { phone: string; street: string; intercom?: string; comment?: string; payMethod: "СБП" | "Наличными" } }
  | { type: "advanceOrderStatus" }
  | { type: "repeatOrder"; orderId: string };

const LS_KEY = "pizza_tagil_state_v1";

const initialState: State = {
  category: "Все",
  cart: [],
  promoCode: "",
  promoApplied: null,
  profile: { name: "Гость", phone: "+7 (___) ___-__-__" },
  savedAddresses: [
    { label: "Дом", phone: "+7 900 000-00-00", street: "Нижний Тагил, ул. Примерная, 10", intercom: "12" },
    { label: "Работа", phone: "+7 900 000-00-00", street: "Нижний Тагил, пр. Ленина, 1" },
  ],
  currentOrder: null,
  orderHistory: [],
};

function rub(n: number) {
  return Math.max(0, Math.round(n));
}

function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

function calcPromoDiscount(code: string, subtotal: number) {
  const c = code.trim().toUpperCase();
  if (!c) return 0;
  if (c === "SBP3") return rub(subtotal * 0.03);
  if (c === "TAGIL50" && subtotal >= 900) return 50;
  return 0;
}

function calcDelivery(subtotal: number) {
  return subtotal >= 800 ? 0 : 150;
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "setCategory":
      return { ...state, category: action.category };

    case "addPizza": {
      const pizza = PIZZAS.find((p) => p.id === action.payload.pizzaId);
      if (!pizza) return state;

      const sizeMul = action.payload.size === 25 ? 1 : action.payload.size === 30 ? 1.2 : 1.45;
      const doughAdd = action.payload.dough === "Традиционное" ? 0 : 39;

      const chosenAddons = action.payload.addonIds
        .map((id) => {
          const a = ADDONS.find((x) => x.id === id);
          return a ? { id: a.id, title: a.title, price: a.price } : null;
        })
        .filter(Boolean) as { id: AddonId; title: string; price: number }[];

      const addonsSum = chosenAddons.reduce((s, a) => s + a.price, 0);
      const price = rub(pizza.basePrice * sizeMul + doughAdd + addonsSum);

      const item: CartItem = {
        id: uid("pizza"),
        type: "pizza",
        title: pizza.title,
        image: pizza.image,
        price,
        qty: 1,
        meta: { size: action.payload.size, dough: action.payload.dough, addons: chosenAddons },
      };

      return { ...state, cart: [item, ...state.cart] };
    }

    case "addAddon": {
      const a = ADDONS.find((x) => x.id === action.addonId);
      if (!a) return state;

      const existing = state.cart.find((i) => i.type === "addon" && i.title === a.title);
      if (existing) {
        return { ...state, cart: state.cart.map((i) => (i.id === existing.id ? { ...i, qty: i.qty + 1 } : i)) };
      }

      const item: CartItem = {
        id: uid("addon"),
        type: "addon",
        title: a.title,
        image: a.image,
        price: a.price,
        qty: 1,
      };

      return { ...state, cart: [item, ...state.cart] };
    }

    case "inc":
      return { ...state, cart: state.cart.map((i) => (i.id === action.id ? { ...i, qty: i.qty + 1 } : i)) };

    case "dec":
      return {
        ...state,
        cart: state.cart
          .map((i) => (i.id === action.id ? { ...i, qty: i.qty - 1 } : i))
          .filter((i) => i.qty > 0),
      };

    case "remove":
      return { ...state, cart: state.cart.filter((i) => i.id !== action.id) };

    case "clearCart":
      return { ...state, cart: [], promoApplied: null, promoCode: "" };

    case "setPromo":
      return { ...state, promoCode: action.code };

    case "applyPromo": {
      const subtotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
      const discount = calcPromoDiscount(action.code, subtotal);
      if (discount <= 0) return { ...state, promoApplied: null };
      return { ...state, promoApplied: { code: action.code.trim().toUpperCase(), discountRub: discount } };
    }

    case "clearPromo":
      return { ...state, promoApplied: null, promoCode: "" };

    case "checkout": {
      const subtotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
      const delivery = calcDelivery(subtotal);
      const discount = state.promoApplied ? state.promoApplied.discountRub : 0;
      const total = rub(subtotal + delivery - discount);

      const order = {
        id: uid("order"),
        createdAt: Date.now(),
        items: state.cart,
        subtotal: rub(subtotal),
        delivery,
        discount,
        total,
        address: {
          phone: action.payload.phone,
          street: action.payload.street,
          intercom: action.payload.intercom,
          comment: action.payload.comment,
        },
        payMethod: action.payload.payMethod,
        status: "Принят" as const,
        etaMin: 35,
      };

      return {
        ...state,
        cart: [],
        promoApplied: null,
        promoCode: "",
        currentOrder: order,
        orderHistory: [order, ...state.orderHistory],
      };
    }

    case "advanceOrderStatus": {
      if (!state.currentOrder) return state;
      const s = state.currentOrder.status;
      const next =
        s === "Принят" ? "Готовится" : s === "Готовится" ? "В пути" : s === "В пути" ? "Доставлен" : "Доставлен";
      const eta = Math.max(0, state.currentOrder.etaMin - (s === "Принят" ? 7 : s === "Готовится" ? 10 : 18));
      const updated = { ...state.currentOrder, status: next, etaMin: eta };
      return {
        ...state,
        currentOrder: updated,
        orderHistory: state.orderHistory.map((o) => (o.id === updated.id ? updated : o)),
      };
    }

    case "repeatOrder": {
      const order = state.orderHistory.find((o) => o.id === action.orderId);
      if (!order) return state;
      return { ...state, cart: order.items.map((i) => ({ ...i, id: uid(i.type) })) };
    }

    default:
      return state;
  }
}

const Ctx = createContext<{
  state: State;
  dispatch: React.Dispatch<Action>;
  formatRub: (n: number) => string;
}>({ state: initialState, dispatch: () => {}, formatRub: (n) => `${rub(n)} ₽` });

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState, (base) => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return base;
      return { ...base, ...JSON.parse(raw) } as State;
    } catch {
      return base;
    }
  });

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(state));
  }, [state]);

  const value = useMemo(
    () => ({
      state,
      dispatch,
      formatRub: (n: number) => `${rub(n)} ₽`,
    }),
    [state]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  return useContext(Ctx);
}
EOF

cat > src/ui/TopBar.tsx <<'EOF'
import { NavLink, useNavigate } from "react-router-dom";

export default function TopBar() {
  const nav = useNavigate();
  return (
    <header className="topbar">
      <div className="topbar__inner">
        <div className="brand" onClick={() => nav("/")}>
          <div className="brand__mark" />
          <div className="brand__text">Пицца Тагил</div>
        </div>

        <nav className="topnav">
          <NavLink to="/" className={({ isActive }) => "topnav__item" + (isActive ? " is-active" : "")}>Меню</NavLink>
          <NavLink to="/cart" className={({ isActive }) => "topnav__item" + (isActive ? " is-active" : "")}>Корзина</NavLink>
          <NavLink to="/profile" className={({ isActive }) => "topnav__item" + (isActive ? " is-active" : "")}>Профиль</NavLink>
        </nav>

        <button className="cta" onClick={() => nav("/")}>Заказать за 45 мин</button>
      </div>
    </header>
  );
}
EOF

cat > src/ui/BottomNav.tsx <<'EOF'
import { NavLink } from "react-router-dom";

export default function BottomNav() {
  return (
    <div className="bottomnav">
      <NavLink to="/" className={({ isActive }) => "bottomnav__item" + (isActive ? " is-active" : "")}>
        <span className="i">🍕</span>
        Меню
      </NavLink>
      <NavLink to="/cart" className={({ isActive }) => "bottomnav__item" + (isActive ? " is-active" : "")}>
        <span className="i">🧺</span>
        Корзина
      </NavLink>
      <NavLink to="/profile" className={({ isActive }) => "bottomnav__item" + (isActive ? " is-active" : "")}>
        <span className="i">👤</span>
        Профиль
      </NavLink>
      <NavLink to="/track" className={({ isActive }) => "bottomnav__item" + (isActive ? " is-active" : "")}>
        <span className="i">🛵</span>
        Трекинг
      </NavLink>
    </div>
  );
}
EOF

cat > src/screens/Home.tsx <<'EOF'
import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { CATEGORIES, PIZZAS } from "../data/catalog";
import { useApp } from "../state/AppState";

export default function Home() {
  const { state, dispatch, formatRub } = useApp();
  const nav = useNavigate();

  const pizzas = useMemo(() => {
    if (state.category === "Все") return PIZZAS;
    return PIZZAS.filter((p) => p.category === state.category);
  }, [state.category]);

  return (
    <div className="container">
      <section className="hero">
        <div className="hero__card">
          <div className="hero__media">
            <img
              src="https://images.unsplash.com/photo-1544986581-efac024faf62?w=1400&auto=format&fit=crop&q=60"
              alt="pizza"
            />
          </div>
          <div className="hero__content">
            <div className="hero__title">Пицца Тагил</div>
            <div className="hero__sub">Тёплая, сочная, быстрая доставка 30–40 мин</div>
            <div className="hero__tags">#E67E22&nbsp;&nbsp;#27AE60</div>
            <button className="cta big" onClick={() => window.scrollTo({ top: 520, behavior: "smooth" })}>
              Заказать за 45 мин
            </button>
          </div>
        </div>
      </section>

      <div className="chips">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            className={"chip" + (state.category === c ? " is-active" : "")}
            onClick={() => dispatch({ type: "setCategory", category: c as any })}
          >
            {c}
          </button>
        ))}
      </div>

      <section className="grid">
        {pizzas.map((p) => (
          <article key={p.id} className="card">
            <div className="card__img">
              <img src={p.image} alt={p.title} />
              <span className="badge">Хит</span>
            </div>
            <div className="card__body">
              <div className="card__title">{p.title}</div>
              <div className="card__row">
                <div className="card__price">{formatRub(p.basePrice)}</div>
                <button className="btnPlus" onClick={() => nav(`/builder/${p.id}`)} title="Настроить и добавить">
                  +
                </button>
              </div>
              <div className="card__hint">Нажми “+” — выберешь размер, тесто и добавки</div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
EOF

cat > src/screens/Builder.tsx <<'EOF'
import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ADDONS, PIZZAS } from "../data/catalog";
import { Dough, Size, useApp } from "../state/AppState";

export default function Builder() {
  const { pizzaId } = useParams();
  const nav = useNavigate();
  const { dispatch, formatRub } = useApp();

  const pizza = useMemo(() => PIZZAS.find((p) => p.id === pizzaId), [pizzaId]);
  const [size, setSize] = useState<Size>(30);
  const [dough, setDough] = useState<Dough>("Тонкое");
  const [addonIds, setAddonIds] = useState<string[]>([]);

  const price = useMemo(() => {
    if (!pizza) return 0;
    const sizeMul = size === 25 ? 1 : size === 30 ? 1.2 : 1.45;
    const doughAdd = dough === "Традиционное" ? 0 : 39;
    const addonsSum = addonIds.reduce((s, id) => {
      const a = ADDONS.find((x) => x.id === id);
      return s + (a?.price ?? 0);
    }, 0);
    return Math.round(pizza.basePrice * sizeMul + doughAdd + addonsSum);
  }, [pizza, size, dough, addonIds]);

  if (!pizza) {
    return (
      <div className="container">
        <div className="panel">
          <div className="h1">Пицца не найдена</div>
          <button className="cta" onClick={() => nav("/")}>На меню</button>
        </div>
      </div>
    );
  }

  function toggleAddon(id: string) {
    setAddonIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [id, ...prev]));
  }

  return (
    <div className="container">
      <div className="builder">
        <div className="builder__top">
          <button className="back" onClick={() => nav(-1)}>← Назад</button>
          <div className="builder__title">{pizza.title}</div>
          <div className="pill">Итого: {formatRub(price)}</div>
        </div>

        <div className="builder__card">
          <div className="builder__img">
            <img src={pizza.image} alt={pizza.title} />
          </div>

          <div className="builder__controls">
            <div className="sectionTitle">Размер</div>
            <div className="seg">
              {[25, 30, 35].map((s) => (
                <button key={s} className={"seg__btn" + (size === s ? " is-active" : "")} onClick={() => setSize(s as Size)}>
                  {s} см
                </button>
              ))}
            </div>

            <div className="sectionTitle">Тесто</div>
            <div className="seg">
              {(["Тонкое", "Традиционное"] as Dough[]).map((d) => (
                <button key={d} className={"seg__btn" + (dough === d ? " is-active" : "")} onClick={() => setDough(d)}>
                  {d}
                </button>
              ))}
            </div>

            <div className="sectionTitle">Добавки</div>
            <div className="addons">
              {[
                { id: "cheese", title: "Сыр +79 ₽", price: 79 },
                { id: "pep", title: "Пепперони +99 ₽", price: 99 },
                { id: "bacon", title: "Бекон +99 ₽", price: 99 },
                { id: "crust", title: "Сырный борт +129 ₽", price: 129 },
              ].map((a) => (
                <label key={a.id} className={"check" + (addonIds.includes(a.id) ? " is-on" : "")}>
                  <input type="checkbox" checked={addonIds.includes(a.id)} onChange={() => toggleAddon(a.id)} />
                  <span>{a.title}</span>
                </label>
              ))}
            </div>

            <div className="reco">
              <div className="sectionTitle">Рекомендуем к этой пицце</div>
              <div className="reco__row">
                {ADDONS.filter((x) => x.kind === "Напитки" || x.kind === "Соусы").slice(0, 3).map((a) => (
                  <button
                    key={a.id}
                    className="miniCard"
                    onClick={() => dispatch({ type: "addAddon", addonId: a.id })}
                    title="Быстро добавить"
                  >
                    <img src={a.image} alt={a.title} />
                    <div className="miniCard__t">{a.title}</div>
                    <div className="miniCard__p">{formatRub(a.price)}</div>
                  </button>
                ))}
              </div>
            </div>

            <button
              className="cta big"
              onClick={() => {
                dispatch({ type: "addPizza", payload: { pizzaId: pizza.id, size, dough, addonIds } });
                nav("/cart");
              }}
            >
              В корзину • {formatRub(price)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
EOF

cat > src/screens/Cart.tsx <<'EOF'
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ADDONS } from "../data/catalog";
import { useApp } from "../state/AppState";

export default function Cart() {
  const { state, dispatch, formatRub } = useApp();
  const nav = useNavigate();

  const [phone, setPhone] = useState(state.savedAddresses[0]?.phone ?? "");
  const [street, setStreet] = useState(state.savedAddresses[0]?.street ?? "");
  const [intercom, setIntercom] = useState(state.savedAddresses[0]?.intercom ?? "");
  const [comment, setComment] = useState("");
  const [payMethod, setPayMethod] = useState<"СБП" | "Наличными">("СБП");
  const [promoTouched, setPromoTouched] = useState(false);

  const subtotal = useMemo(() => state.cart.reduce((s, i) => s + i.price * i.qty, 0), [state.cart]);
  const delivery = subtotal >= 800 ? 0 : 150;
  const discount = state.promoApplied?.discountRub ?? 0;
  const total = Math.max(0, Math.round(subtotal + delivery - discount));

  const leftToFree = Math.max(0, 800 - subtotal);
  const prog = Math.min(1, subtotal / 800);

  const canCheckout = state.cart.length > 0 && phone.trim().length >= 6 && street.trim().length >= 6;

  return (
    <div className="container">
      <div className="cartLayout">
        <section className="panel">
          <div className="h1">Корзина</div>

          {state.cart.length === 0 ? (
            <div className="empty">
              <div className="empty__title">Пока пусто</div>
              <div className="empty__sub">Выбери пиццу — и она тут появится 🍕</div>
              <button className="cta" onClick={() => nav("/")}>Перейти в меню</button>
            </div>
          ) : (
            <div className="cartList">
              {state.cart.map((i) => (
                <div key={i.id} className="cartItem">
                  <img className="cartItem__img" src={i.image} alt={i.title} />
                  <div className="cartItem__mid">
                    <div className="cartItem__title">{i.title}</div>
                    {i.type === "pizza" && (
                      <div className="cartItem__meta">
                        {i.meta?.size} см • {i.meta?.dough}
                        {i.meta?.addons?.length ? (
                          <div className="cartItem__addons">
                            + {i.meta.addons.map((a) => a.title).join(", ")}
                          </div>
                        ) : null}
                      </div>
                    )}
                  </div>

                  <div className="cartItem__right">
                    <div className="qty">
                      <button onClick={() => dispatch({ type: "dec", id: i.id })}>–</button>
                      <div>{i.qty}</div>
                      <button onClick={() => dispatch({ type: "inc", id: i.id })}>+</button>
                    </div>
                    <div className="cartItem__price">{formatRub(i.price * i.qty)}</div>
                    <button className="trash" onClick={() => dispatch({ type: "remove", id: i.id })} title="Удалить">🗑</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {state.cart.length > 0 && (
            <>
              <div className="panel__sep" />

              <div className="h2">Добавить к заказу</div>
              <div className="addonRow">
                {ADDONS.map((a) => (
                  <button key={a.id} className="addonCard" onClick={() => dispatch({ type: "addAddon", addonId: a.id })}>
                    <img src={a.image} alt={a.title} />
                    <div className="addonCard__t">{a.title}</div>
                    <div className="addonCard__p">{formatRub(a.price)}</div>
                    <div className="addonCard__btn">+ Добавить</div>
                  </button>
                ))}
              </div>

              <div className="panel__sep" />

              <div className="h2">Адрес и оплата</div>
              <div className="formGrid">
                <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Телефон" />
                <input className="input" value={street} onChange={(e) => setStreet(e.target.value)} placeholder="Улица, дом, кв." />
                <input className="input" value={intercom} onChange={(e) => setIntercom(e.target.value)} placeholder="Домофон (необязательно)" />
                <input className="input" value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Комментарий (например: подъезд, этаж)" />
              </div>

              <div className="seg">
                <button className={"seg__btn" + (payMethod === "СБП" ? " is-active" : "")} onClick={() => setPayMethod("СБП")}>
                  Оплатить через СБП
                </button>
                <button className={"seg__btn" + (payMethod === "Наличными" ? " is-active" : "")} onClick={() => setPayMethod("Наличными")}>
                  Наличными
                </button>
              </div>
            </>
          )}
        </section>

        <aside className="panel sticky">
          <div className="h2">Промокод</div>
          <div className="promo">
            <input
              className="input"
              value={state.promoCode}
              onChange={(e) => {
                setPromoTouched(true);
                dispatch({ type: "setPromo", code: e.target.value });
              }}
              placeholder="Например: SBP3"
            />
            <button
              className="btn"
              onClick={() => {
                setPromoTouched(true);
                dispatch({ type: "applyPromo", code: state.promoCode });
              }}
            >
              Применить
            </button>
          </div>

          {promoTouched && state.promoCode.trim() && !state.promoApplied && (
            <div className="note is-bad">Промокод не подошёл. Попробуй: <b>SBP3</b> или <b>TAGIL50</b> (от 900 ₽).</div>
          )}
          {state.promoApplied && (
            <div className="note is-good">Скидка применена: <b>{state.promoApplied.code}</b> (–{formatRub(state.promoApplied.discountRub)})</div>
          )}

          <div className="panel__sep" />

          <div className="h2">Итоги</div>
          <div className="totals">
            <div className="row"><span>Сумма товаров</span><b>{formatRub(subtotal)}</b></div>
            <div className="row"><span>Доставка</span><b>{delivery === 0 ? "Бесплатно" : formatRub(delivery)}</b></div>
            <div className="row"><span>Скидка</span><b>–{formatRub(discount)}</b></div>
            <div className="row total"><span>Итого</span><b>{formatRub(total)}</b></div>
          </div>

          <div className="free">
            <div className="free__t">
              {leftToFree > 0 ? <>До бесплатной доставки осталось <b>{formatRub(leftToFree)}</b></> : <>Бесплатная доставка активна ✅</>}
            </div>
            <div className="bar"><div className="bar__fill" style={{ width: `${prog * 100}%` }} /></div>
          </div>

          <div className="panel__sep" />

          <div className="ctaRow">
            <button className="btn ghost" onClick={() => nav("/")}>Продолжить выбор</button>
            <button
              className={"cta" + (canCheckout ? "" : " is-disabled")}
              disabled={!canCheckout}
              onClick={() => {
                dispatch({ type: "checkout", payload: { phone, street, intercom, comment, payMethod } });
                nav("/track");
              }}
            >
              Перейти к адресу → Оплатить
            </button>
          </div>

          <div className="micro">
            Подсказка: промокод <b>SBP3</b> даёт 3% скидки при оплате через СБП.
          </div>
        </aside>
      </div>
    </div>
  );
}
EOF

cat > src/screens/Profile.tsx <<'EOF'
import { useNavigate } from "react-router-dom";
import { useApp } from "../state/AppState";

export default function Profile() {
  const { state, dispatch, formatRub } = useApp();
  const nav = useNavigate();

  return (
    <div className="container">
      <div className="profile">
        <div className="panel">
          <div className="profileHead">
            <div className="avatar">👤</div>
            <div>
              <div className="h1">Личный кабинет</div>
              <div className="sub">{state.profile.name} • {state.profile.phone}</div>
            </div>
            <button className="btn ghost" onClick={() => alert("Пока без авторизации. Позже подключим SMS/Telegram.")}>
              Выйти
            </button>
          </div>

          {state.currentOrder ? (
            <div className="currentOrder">
              <div className="h2">Текущий заказ</div>
              <div className="orderCard">
                <div>
                  <div className="orderStatus">{state.currentOrder.status}</div>
                  <div className="orderEta">Привезём через <b>{state.currentOrder.etaMin} мин</b></div>
                </div>
                <div className="orderBtns">
                  <button className="btn" onClick={() => alert("Звонок: позже подключим номер/телефонию")}>Позвонить</button>
                  <button className="btn ghost" onClick={() => nav("/track")}>Открыть трекинг</button>
                </div>
              </div>
              <div className="note is-good">Мы уже готовим вашу пиццу. Спасибо! ❤️</div>
            </div>
          ) : (
            <div className="note">Сейчас активного заказа нет. Самое время выбрать пиццу 🍕</div>
          )}
        </div>

        <div className="panel">
          <div className="h2">История заказов</div>
          {state.orderHistory.length === 0 ? (
            <div className="empty small">
              <div className="empty__sub">Как только сделаешь первый заказ — тут появится история.</div>
            </div>
          ) : (
            <div className="history">
              {state.orderHistory.map((o) => (
                <div key={o.id} className="historyItem">
                  <div>
                    <div className="historyTop">
                      <b>{new Date(o.createdAt).toLocaleString()}</b>
                      <span className="pill small">{formatRub(o.total)}</span>
                    </div>
                    <div className="historySub">
                      {o.items.slice(0, 2).map((it) => it.title).join(", ")}
                      {o.items.length > 2 ? ` и ещё ${o.items.length - 2}` : ""}
                    </div>
                  </div>
                  <button className="cta" onClick={() => dispatch({ type: "repeatOrder", orderId: o.id })}>
                    Повторить
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="panel__sep" />

          <div className="h2">Бонусы и акции</div>
          <div className="bonus">
            <div className="bonus__left">
              <div className="bonus__num">240</div>
              <div className="bonus__txt">бонусов</div>
              <div className="bonus__hint">1 бонус = 1 ₽ скидки</div>
            </div>
            <div className="bonus__right">
              <div className="free__t">До подарка осталось <b>260 ₽</b></div>
              <div className="bar"><div className="bar__fill" style={{ width: "48%" }} /></div>
              <div className="micro">Каждая 5-я пицца — подарок (скоро сделаем красиво)</div>
            </div>
          </div>

          <div className="panel__sep" />

          <div className="h2">Сохранённые адреса</div>
          <div className="addrList">
            {state.savedAddresses.map((a) => (
              <div key={a.label} className="addr">
                <div>
                  <b>{a.label}</b>
                  <div className="sub">{a.street}</div>
                </div>
                <button className="btn ghost" onClick={() => alert("Редактор адресов добавим следующим шагом")}>
                  Редактировать
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
EOF

cat > src/screens/Track.tsx <<'EOF'
import { useEffect } from "react";
import { useApp } from "../state/AppState";
import { useNavigate } from "react-router-dom";

export default function Track() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();

  useEffect(() => {
    if (!state.currentOrder) return;
    if (state.currentOrder.status === "Доставлен") return;

    const t = setInterval(() => {
      dispatch({ type: "advanceOrderStatus" });
    }, 7000);

    return () => clearInterval(t);
  }, [state.currentOrder, dispatch]);

  if (!state.currentOrder) {
    return (
      <div className="container">
        <div className="panel">
          <div className="h1">Трекинг</div>
          <div className="note">Сначала оформи заказ — и тут появится доставка.</div>
          <button className="cta" onClick={() => nav("/")}>В меню</button>
        </div>
      </div>
    );
  }

  const s = state.currentOrder.status;
  const steps: Array<{ key: any; title: string }> = [
    { key: "Принят", title: "Принят" },
    { key: "Готовится", title: "Готовится" },
    { key: "В пути", title: "В пути" },
    { key: "Доставлен", title: "Доставлен" },
  ];

  const activeIndex = steps.findIndex((x) => x.key === s);

  return (
    <div className="container">
      <div className="panel">
        <div className="h1">Доставка</div>

        <div className="trackHero">
          <div className="trackTime">
            Заказ приедет через <span>{state.currentOrder.etaMin} мин</span>
          </div>

          <div className="trackSteps">
            {steps.map((st, idx) => (
              <div key={st.title} className={"step" + (idx <= activeIndex ? " is-on" : "")}>
                <div className="dot" />
                <div className="lbl">{st.title}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="panel__sep" />

        <div className="courier">
          <div>
            <div className="h2">Курьер</div>
            <div className="sub">Данил • на скутере 🛵</div>
          </div>
          <div className="orderBtns">
            <button className="btn" onClick={() => alert("Позже подключим звонок")}>Позвонить</button>
            <button className="btn ghost" onClick={() => alert("Позже подключим чат/Telegram")}>Написать</button>
          </div>
        </div>

        <div className="addrBlock">
          <div>
            <div className="h2">Адрес</div>
            <div className="sub">{state.currentOrder.address?.street}</div>
          </div>
          <button className="btn ghost" onClick={() => alert("Комментарий к адресу добавим следующим шагом")}>
            Изменить комментарий
          </button>
        </div>

        <div className={"note " + (state.currentOrder.payMethod === "СБП" ? "is-good" : "")}>
          {state.currentOrder.payMethod === "СБП"
            ? "Оплата уже прошла через СБП ✅ Спасибо!"
            : "Подготовьте наличные — курьер будет рад без сдачи 🙂"}
        </div>

        <div className="panel__sep" />

        <div className="ctaRow">
          <button className="btn ghost" onClick={() => nav("/profile")}>В профиль</button>
          <button className="cta" onClick={() => nav("/")}>Ещё пиццу 🍕</button>
        </div>
      </div>
    </div>
  );
}
EOF

cat > src/styles.css <<'EOF'
:root{
  --bg: #f7ecd7;
  --card: rgba(255,255,255,0.55);
  --stroke: rgba(0,0,0,0.08);
  --text: #1f1b16;
  --muted: rgba(0,0,0,0.55);

  --orange: #E67E22;
  --green: #27AE60;

  --shadow: 0 16px 40px rgba(0,0,0,0.12);
  --shadow2: 0 10px 24px rgba(0,0,0,0.12);

  --r: 22px;
}

*{ box-sizing:border-box; }
html,body{ height:100%; }
body{
  margin:0;
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, "Noto Sans";
  color:var(--text);
  background:
    radial-gradient(900px 600px at 80% 0%, rgba(255,128,0,0.45), transparent 60%),
    radial-gradient(900px 600px at 10% 20%, rgba(39,174,96,0.22), transparent 55%),
    linear-gradient(180deg, #f6e3c7, #f7ecd7);
}

a{ color:inherit; text-decoration:none; }

.app{ min-height:100vh; display:flex; flex-direction:column; }
.page{ padding:18px 14px 90px; }
.container{ max-width:1100px; margin:0 auto; }

.topbar{
  position:sticky; top:0; z-index:10;
  backdrop-filter: blur(18px);
  background: rgba(30, 20, 12, 0.65);
  border-bottom: 1px solid rgba(255,255,255,0.10);
}
.topbar__inner{
  max-width:1100px;
  margin:0 auto;
  display:flex;
  align-items:center;
  gap:14px;
  padding:14px;
}
.brand{ display:flex; align-items:center; gap:10px; cursor:pointer; }
.brand__mark{
  width:14px; height:14px; border-radius:6px;
  background: linear-gradient(135deg, var(--orange), var(--green));
  box-shadow: 0 6px 14px rgba(230,126,34,0.35);
}
.brand__text{ color:#ffb065; font-weight:800; }
.topnav{ display:flex; gap:10px; margin-left:18px; }
.topnav__item{
  color: rgba(255,255,255,0.82);
  padding:8px 12px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,0.10);
}
.topnav__item.is-active{ background: rgba(255,255,255,0.12); border-color: rgba(255,255,255,0.18); }

.cta{
  margin-left:auto;
  background: linear-gradient(135deg, var(--orange), var(--green));
  color:white;
  border:none;
  border-radius:999px;
  padding:10px 14px;
  font-weight:800;
  cursor:pointer;
  box-shadow: 0 12px 28px rgba(0,0,0,0.25);
}
.cta.big{ padding:12px 16px; font-size:16px; }
.cta.is-disabled{ opacity:0.5; cursor:not-allowed; }

.bottomnav{
  position:fixed;
  left:0; right:0; bottom:0;
  display:flex;
  justify-content:space-around;
  gap:8px;
  padding:10px 10px env(safe-area-inset-bottom);
  background: rgba(30, 20, 12, 0.72);
  backdrop-filter: blur(18px);
  border-top:1px solid rgba(255,255,255,0.10);
  z-index:20;
}
.bottomnav__item{
  display:flex; flex-direction:column; align-items:center; gap:4px;
  color: rgba(255,255,255,0.78);
  padding:8px 12px;
  border-radius:16px;
}
.bottomnav__item .i{ font-size:18px; }
.bottomnav__item.is-active{ background: rgba(255,255,255,0.10); color:#fff; }

.hero{ margin-top:18px; }
.hero__card{
  border-radius: 26px;
  overflow:hidden;
  box-shadow: var(--shadow);
  background: linear-gradient(135deg, rgba(0,0,0,0.72), rgba(0,0,0,0.35));
  border: 1px solid rgba(255,255,255,0.10);
  display:grid;
  grid-template-columns: 1.1fr 1fr;
  min-height: 280px;
}
.hero__media img{ width:100%; height:100%; object-fit:cover; filter: saturate(1.1) contrast(1.03); }
.hero__content{
  padding:22px;
  background: linear-gradient(135deg, rgba(230,126,34,0.85), rgba(39,174,96,0.65));
  display:flex; flex-direction:column; gap:10px; justify-content:center;
}
.hero__title{ font-size:48px; font-weight:900; color:#fff; line-height:1.0; }
.hero__sub{ color: rgba(255,255,255,0.92); font-size:16px; font-weight:700; }
.hero__tags{ color: rgba(255,255,255,0.9); font-weight:800; }

.chips{ display:flex; gap:10px; flex-wrap:wrap; margin:16px 0 12px; }
.chip{
  border:none; cursor:pointer;
  padding:10px 14px; border-radius:999px;
  background: rgba(255,255,255,0.55);
  border:1px solid var(--stroke);
  font-weight:800;
}
.chip.is-active{
  background: linear-gradient(135deg, rgba(230,126,34,0.55), rgba(39,174,96,0.35));
}

.grid{ display:grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap:14px; }

.card{
  border-radius: var(--r);
  overflow:hidden;
  background: rgba(255,255,255,0.58);
  border: 1px solid var(--stroke);
  box-shadow: var(--shadow2);
}
.card__img{ position:relative; height: 150px; }
.card__img img{ width:100%; height:100%; object-fit:cover; }
.badge{
  position:absolute; top:10px; right:10px;
  background: rgba(255, 125, 0, 0.92);
  color:white;
  font-weight:900;
  border-radius:999px;
  padding:6px 10px;
  border: 2px solid rgba(255,255,255,0.85);
}
.card__body{ padding:12px 12px 14px; }
.card__title{ font-weight:900; font-size:18px; }
.card__row{ display:flex; align-items:center; justify-content:space-between; margin-top:10px; }
.card__price{ font-weight:900; font-size:18px; }
.btnPlus{
  width:40px; height:40px;
  border-radius:999px;
  border:none; cursor:pointer;
  background: rgba(0,0,0,0.85);
  color:white; font-size:20px;
}
.card__hint{ margin-top:8px; color: var(--muted); font-size:12px; font-weight:700; }

.panel{
  background: rgba(255,255,255,0.55);
  border:1px solid var(--stroke);
  border-radius: 22px;
  padding:16px;
  box-shadow: var(--shadow2);
}
.panel.sticky{ position:sticky; top:86px; height:fit-content; }
.panel__sep{ height:1px; background: rgba(0,0,0,0.08); margin:14px 0; }

.h1{ font-size:34px; font-weight:1000; }
.h2{ font-size:18px; font-weight:1000; margin:0 0 10px; }
.sub{ color: var(--muted); font-weight:800; }

.cartLayout{ display:grid; grid-template-columns: 1.4fr 0.8fr; gap:14px; margin-top:16px; }
.cartList{ display:flex; flex-direction:column; gap:10px; }
.cartItem{
  display:grid; grid-template-columns: 64px 1fr auto; gap:10px;
  padding:10px; border-radius: 18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
}
.cartItem__img{ width:64px; height:64px; border-radius:16px; object-fit:cover; }
.cartItem__title{ font-weight:1000; }
.cartItem__meta{ margin-top:4px; color:var(--muted); font-weight:800; font-size:12px; }
.cartItem__right{ display:flex; align-items:center; gap:10px; }
.cartItem__price{ font-weight:1000; min-width:88px; text-align:right; }
.trash{ border:none; cursor:pointer; background: rgba(0,0,0,0.06); border-radius: 12px; padding:8px 10px; }
.qty{ display:flex; align-items:center; gap:8px; }
.qty button{
  width:34px; height:34px;
  border:none; cursor:pointer;
  border-radius: 12px;
  background: rgba(0,0,0,0.85);
  color:#fff; font-weight:1000;
}
.qty div{ width:22px; text-align:center; font-weight:1000; }

.addonRow{ display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:10px; }
.addonCard{
  border:none; cursor:pointer; text-align:left;
  border-radius: 18px; overflow:hidden;
  background: rgba(255,255,255,0.6);
  border:1px solid rgba(0,0,0,0.08);
  padding:10px;
}
.addonCard img{ width:100%; height:90px; object-fit:cover; border-radius:14px; }
.addonCard__t{ font-weight:1000; margin-top:8px; }
.addonCard__p{ color: var(--muted); font-weight:1000; }
.addonCard__btn{
  margin-top:8px;
  background: rgba(0,0,0,0.85);
  color:#fff;
  padding:8px 10px;
  border-radius: 14px;
  font-weight:1000;
  display:inline-block;
}

.promo{ display:flex; gap:10px; }
.input{
  width:100%;
  padding:12px 12px;
  border-radius: 16px;
  border:1px solid rgba(0,0,0,0.10);
  background: rgba(255,255,255,0.6);
  font-weight:900;
  outline:none;
}
.btn{
  border:none; cursor:pointer;
  padding:12px 12px;
  border-radius: 16px;
  background: rgba(0,0,0,0.85);
  color:#fff;
  font-weight:1000;
}
.btn.ghost{
  background: rgba(0,0,0,0.06);
  color: rgba(0,0,0,0.85);
  border:1px solid rgba(0,0,0,0.10);
}

.note{
  margin-top:10px;
  padding:12px;
  border-radius: 16px;
  background: rgba(0,0,0,0.05);
  border:1px solid rgba(0,0,0,0.08);
  font-weight:900;
}
.note.is-good{ background: rgba(39,174,96,0.12); border-color: rgba(39,174,96,0.20); }
.note.is-bad{ background: rgba(230,126,34,0.12); border-color: rgba(230,126,34,0.20); }

.totals .row{ display:flex; justify-content:space-between; padding:6px 0; font-weight:900; }
.totals .row.total{ font-size:20px; padding-top:10px; border-top:1px dashed rgba(0,0,0,0.14); margin-top:8px; }
.free{ margin-top:12px; }
.free__t{ font-weight:900; color: rgba(0,0,0,0.75); }
.bar{ margin-top:8px; height:12px; border-radius:999px; background: rgba(0,0,0,0.08); overflow:hidden; }
.bar__fill{ height:100%; background: linear-gradient(135deg, var(--orange), var(--green)); }

.ctaRow{ display:flex; gap:10px; align-items:center; }
.micro{ margin-top:10px; color: var(--muted); font-weight:800; font-size:12px; }

.formGrid{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
.seg{ display:flex; gap:10px; }
.seg__btn{
  flex:1; border:none; cursor:pointer;
  padding:12px; border-radius: 18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.10);
  font-weight:1000;
}
.seg__btn.is-active{ background: linear-gradient(135deg, rgba(230,126,34,0.45), rgba(39,174,96,0.25)); }

.profile{ display:grid; grid-template-columns: 1fr; gap:14px; margin-top:16px; }
.profileHead{ display:flex; align-items:center; gap:12px; }
.avatar{
  width:56px; height:56px; border-radius:18px;
  display:grid; place-items:center;
  background: linear-gradient(135deg, rgba(230,126,34,0.35), rgba(39,174,96,0.20));
  font-size:22px; border:1px solid rgba(0,0,0,0.08);
}
.currentOrder{ margin-top:12px; }
.orderCard{
  display:flex; justify-content:space-between; align-items:center;
  padding:14px; border-radius:18px;
  background: linear-gradient(135deg, rgba(230,126,34,0.35), rgba(39,174,96,0.18));
  border:1px solid rgba(0,0,0,0.10);
}
.orderStatus{ font-weight:1000; font-size:16px; }
.orderEta{ margin-top:6px; font-weight:900; color: rgba(0,0,0,0.75); }
.orderBtns{ display:flex; gap:10px; flex-wrap:wrap; }
.history{ display:flex; flex-direction:column; gap:10px; }
.historyItem{
  display:flex; justify-content:space-between; gap:10px; align-items:center;
  padding:12px; border-radius:18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
}
.historyTop{ display:flex; gap:10px; align-items:center; }
.pill{ padding:8px 12px; border-radius:999px; background: rgba(0,0,0,0.10); border:1px solid rgba(0,0,0,0.12); font-weight:1000; }
.pill.small{ padding:6px 10px; font-size:12px; }
.historySub{ margin-top:4px; color: var(--muted); font-weight:900; font-size:12px; }

.bonus{
  display:flex; gap:14px; align-items:stretch;
  border-radius: 20px; padding:14px;
  border:1px solid rgba(0,0,0,0.10);
  background: linear-gradient(135deg, rgba(39,174,96,0.18), rgba(230,126,34,0.16));
}
.bonus__left{ min-width:120px; }
.bonus__num{ font-size:40px; font-weight:1100; }
.bonus__txt{ font-weight:1000; }
.bonus__hint{ margin-top:6px; color: var(--muted); font-weight:900; font-size:12px; }
.bonus__right{ flex:1; display:flex; flex-direction:column; justify-content:center; }

.addrList{ display:flex; flex-direction:column; gap:10px; }
.addr{
  display:flex; justify-content:space-between; align-items:center; gap:10px;
  padding:12px; border-radius:18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
}

.builder{ margin-top:16px; }
.builder__top{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px; }
.back{
  border:none; cursor:pointer;
  background: rgba(0,0,0,0.06);
  border:1px solid rgba(0,0,0,0.10);
  padding:10px 12px; border-radius: 16px;
  font-weight:1000;
}
.builder__title{ font-size:22px; font-weight:1100; }
.builder__card{
  display:grid; grid-template-columns: 1fr 1fr; gap:14px;
  padding:14px; border-radius: 24px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
  box-shadow: var(--shadow2);
}
.builder__img img{ width:100%; height:360px; object-fit:cover; border-radius: 22px; }
.builder__controls{ display:flex; flex-direction:column; gap:12px; }
.sectionTitle{ font-weight:1100; }
.addons{ display:grid; gap:10px; }
.check{
  display:flex; gap:10px; align-items:center;
  padding:12px; border-radius: 18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.10);
  font-weight:1000; cursor:pointer;
}
.check input{ display:none; }
.check.is-on{ background: rgba(39,174,96,0.14); border-color: rgba(39,174,96,0.22); }
.reco__row{ display:grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap:10px; }
.miniCard{
  border:none; cursor:pointer;
  border-radius: 18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
  padding:10px; text-align:left;
}
.miniCard img{ width:100%; height:80px; object-fit:cover; border-radius:14px; }
.miniCard__t{ font-weight:1000; margin-top:6px; }
.miniCard__p{ color: var(--muted); font-weight:1000; font-size:12px; }

.trackHero{
  border-radius: 22px; padding:14px;
  background: linear-gradient(135deg, rgba(230,126,34,0.22), rgba(39,174,96,0.14));
  border:1px solid rgba(0,0,0,0.10);
}
.trackTime{ font-weight:1100; font-size:18px; }
.trackTime span{ font-size:26px; }
.trackSteps{ display:flex; gap:12px; margin-top:12px; flex-wrap:wrap; }
.step{
  display:flex; align-items:center; gap:8px;
  padding:10px 12px; border-radius: 999px;
  background: rgba(255,255,255,0.50);
  border:1px solid rgba(0,0,0,0.08);
  font-weight:1000; color: rgba(0,0,0,0.55);
}
.step .dot{ width:10px; height:10px; border-radius:999px; background: rgba(0,0,0,0.20); }
.step.is-on{ color: rgba(0,0,0,0.9); background: rgba(39,174,96,0.16); border-color: rgba(39,174,96,0.22); }
.step.is-on .dot{ background: linear-gradient(135deg, var(--orange), var(--green)); }

.courier, .addrBlock{
  display:flex; justify-content:space-between; align-items:center; gap:10px;
  padding:12px; border-radius: 18px;
  background: rgba(255,255,255,0.55);
  border:1px solid rgba(0,0,0,0.08);
}

.empty{ padding:18px; border-radius:18px; background: rgba(0,0,0,0.04); border:1px dashed rgba(0,0,0,0.12); }
.empty__title{ font-weight:1100; font-size:18px; }
.empty__sub{ margin-top:6px; color: var(--muted); font-weight:900; }
.empty.small{ padding:12px; }

@media (max-width: 980px){
  .grid{ grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .hero__card{ grid-template-columns: 1fr; }
  .hero__title{ font-size:38px; }
  .cartLayout{ grid-template-columns: 1fr; }
  .panel.sticky{ position:static; }
  .addonRow{ grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .formGrid{ grid-template-columns: 1fr; }
  .builder__card{ grid-template-columns: 1fr; }
  .builder__img img{ height:260px; }
}
EOF

# Важно: Vite шаблон создаёт App.css и index.css — удалим импортные следы
# и оставим только styles.css.
# Поправим src/main.tsx уже у нас, осталось убрать лишние css файлы.
rm -f src/App.css src/index.css || true

echo "==> Готово. Запуск:"
echo "   cd $APP_DIR"
echo "   npm run dev"
EOF

chmod +x 1.sh

echo
echo "Создан скрипт: $APP_DIR/init_pizza_tagil_app.sh"
echo "Запусти так:"
echo "  cd $APP_DIR"
echo "  ./init_pizza_tagil_app.sh"
echo "  npm run dev"

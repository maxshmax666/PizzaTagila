cat > move_archive_to_documents.sh <<'EOF'
#!/usr/bin/env bash
set -e

DEST="/storage/emulated/0/Documents"

# ищем самый свежий архив
ARCHIVE=$(ls -t *.tar.gz 2>/dev/null | head -n 1)

if [ -z "$ARCHIVE" ]; then
  echo "❌ Архив *.tar.gz не найден в текущей папке"
  exit 1
fi

echo "📦 Найден архив: $ARCHIVE"
echo "📂 Копируем в: $DEST"

cp "$ARCHIVE" "$DEST/"

echo "✅ Готово!"
echo "📁 Файл доступен в Documents: $ARCHIVE"
EOF

chmod +x move_archive_to_documents.sh
